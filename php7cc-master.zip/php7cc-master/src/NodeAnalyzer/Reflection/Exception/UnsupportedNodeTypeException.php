<?php

namespace Sstalle\php7cc\NodeAnalyzer\Reflection\Exception;

class UnsupportedNodeTypeException extends \RuntimeException
{
}

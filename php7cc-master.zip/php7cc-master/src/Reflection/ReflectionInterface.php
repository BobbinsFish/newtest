<?php

namespace Sstalle\php7cc\Reflection;

interface ReflectionInterface
{
    /**
     * @return string
     */
    public function getName();
}

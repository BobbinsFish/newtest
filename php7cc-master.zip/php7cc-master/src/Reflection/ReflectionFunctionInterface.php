<?php

namespace Sstalle\php7cc\Reflection;

interface ReflectionFunctionInterface extends ReflectionFunctionAbstractInterface
{
}

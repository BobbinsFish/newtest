<?php

namespace Sstalle\php7cc\Reflection\Internal;

use Sstalle\php7cc\Reflection\ReflectionMethodInterface;

class ReflectionMethod extends ReflectionFunctionAbstract implements ReflectionMethodInterface
{
}

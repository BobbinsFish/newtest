<?php

namespace Sstalle\php7cc\Reflection\Internal;

use Sstalle\php7cc\Reflection\ReflectionFunctionInterface;

class ReflectionFunction extends ReflectionFunctionAbstract implements ReflectionFunctionInterface
{
}
